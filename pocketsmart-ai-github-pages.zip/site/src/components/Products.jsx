import { ExternalLink } from 'lucide-react'
import { inr } from '../api.js'
import { PRODUCTS, PRODUCT_NOTICE } from '../demo.js'
import { Card } from './ui.jsx'

export default function Products({ category }) {
  const items = PRODUCTS.filter((p) => !category || p.category === category)
  const notice = PRODUCT_NOTICE
  return (
    <section className="mt-10">
      <h2 className="mb-1 text-xl font-bold">Recommended products</h2>
      <p className="mb-4 text-xs text-muted">{notice}</p>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((p) => (
          <Card key={p.id}>
            <div className="mb-3 flex h-28 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500/30 to-fuchsia-500/30 text-5xl">{p.emoji}</div>
            <div className="flex items-start justify-between gap-2"><h3 className="font-semibold">{p.name}</h3><span className="rounded bg-amber-400/20 px-1.5 py-0.5 text-[10px] text-amber-300">SAMPLE</span></div>
            <p className="mt-1 text-sm text-muted">{p.description}</p>
            <div className="mt-3 flex items-center justify-between text-sm">
              <span><b>~{inr(p.price)}</b> <span className="text-muted">est.</span></span>
              <a href={p.url} target="_blank" rel="noreferrer noopener" className="flex items-center gap-1 text-violet-400 hover:underline">{p.platform} <ExternalLink size={14} /></a>
            </div>
          </Card>
        ))}
      </div>
    </section>
  )
}
