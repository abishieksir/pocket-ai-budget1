import { motion } from 'framer-motion'
import { Loader2 } from 'lucide-react'

export const Page = ({ children, className = '' }) => (
  <motion.main initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
    transition={{ duration: .35 }} className={`mx-auto max-w-6xl px-4 pb-20 pt-24 ${className}`}>{children}</motion.main>
)
export const Card = ({ children, className = '', ...p }) => (
  <motion.div whileHover={{ y: -3 }} className={`glass p-5 ${className}`} {...p}>{children}</motion.div>
)
export const Spinner = ({ label = 'Thinking…' }) => (
  <div className="flex items-center gap-2 text-muted"><Loader2 className="animate-spin" size={18} /> {label}</div>
)
export const Field = ({ label, children }) => (
  <label className="block text-sm"><span className="mb-1 block text-muted">{label}</span>{children}</label>
)
export const COLORS = ['#7c6dff', '#c25bf5', '#38bdf8', '#34d399', '#fbbf24', '#fb7185', '#a3e635']
