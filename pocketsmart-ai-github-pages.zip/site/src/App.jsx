import { useEffect, useState } from 'react'
import { AuthCtx } from './auth.js'
import { Routes, Route, NavLink, Link, useLocation, useNavigate } from 'react-router-dom'
import { AnimatePresence } from 'framer-motion'
import { Sparkles, Sun, Moon, Menu, X } from 'lucide-react'
import Landing from './pages/Landing.jsx'
import Auth from './pages/Auth.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Planner from './pages/Planner.jsx'
import Chat from './pages/Chat.jsx'
import Expenses from './pages/Expenses.jsx'
import { About, Contact } from './pages/Static.jsx'

const LINKS = [
  ['/dashboard', 'Dashboard'], ['/budget', 'Budget'], ['/home-planner', 'Home'], ['/party', 'Party'],
  ['/jewelry', 'Jewelry'], ['/chat', 'AI Chat'], ['/expenses', 'Expenses'], ['/about', 'About'], ['/contact', 'Contact'],
]

export default function App() {
  const loc = useLocation()
  const nav = useNavigate()
  const [open, setOpen] = useState(false)
  const [light, setLight] = useState(localStorage.getItem('ps_theme') === 'light')
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('ps_user') || 'null'))

  useEffect(() => {
    document.documentElement.classList.toggle('light', light)
    localStorage.setItem('ps_theme', light ? 'light' : 'dark')
  }, [light])
  useEffect(() => { setOpen(false); window.scrollTo(0, 0) }, [loc.pathname])

  const login = (u) => { localStorage.setItem('ps_user', JSON.stringify(u)); setUser(u) }
  const logout = () => { localStorage.removeItem('ps_user'); setUser(null); nav('/') }

  return (
    <AuthCtx.Provider value={{ user, login, logout }}>
      <div className="blob left-[-10%] top-[-10%] h-[28rem] w-[28rem] bg-indigo-600" />
      <div className="blob bottom-[-10%] right-[-5%] h-[30rem] w-[30rem] bg-fuchsia-600" style={{ animationDelay: '-6s' }} />
      <header className="glass fixed inset-x-3 top-3 z-50 flex items-center justify-between rounded-2xl px-4 py-2.5">
        <Link to="/" className="flex items-center gap-2 font-bold"><Sparkles className="text-violet-400" size={20} /> <span className="gradient-text">PocketSmart AI</span></Link>
        <nav className="hidden items-center gap-1 lg:flex">
          {LINKS.map(([to, label]) => (
            <NavLink key={to} to={to} className={({ isActive }) => `btn-ghost ${isActive ? 'bg-white/10 text-violet-400' : 'text-muted'}`}>{label}</NavLink>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <button className="btn-ghost" aria-label="Toggle theme" onClick={() => setLight(!light)}>{light ? <Moon size={18} /> : <Sun size={18} />}</button>
          {user ? <button className="btn-ghost" onClick={logout}>Log out</button> : <Link to="/auth" className="btn !py-1.5 text-sm">Log in</Link>}
          <button className="btn-ghost lg:hidden" aria-label="Menu" onClick={() => setOpen(!open)}>{open ? <X size={20} /> : <Menu size={20} />}</button>
        </div>
      </header>
      {open && (
        <div className="glass fixed inset-x-3 top-[4.5rem] z-40 grid gap-1 p-3 lg:hidden">
          {LINKS.map(([to, label]) => <NavLink key={to} to={to} className="btn-ghost">{label}</NavLink>)}
        </div>
      )}
      <AnimatePresence mode="wait">
        <Routes location={loc} key={loc.pathname}>
          <Route path="/" element={<Landing />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/budget" element={<Planner kind="budget" />} />
          <Route path="/home-planner" element={<Planner kind="home" />} />
          <Route path="/party" element={<Planner kind="party" />} />
          <Route path="/jewelry" element={<Planner kind="jewelry" />} />
          <Route path="/chat" element={<Chat />} />
          <Route path="/expenses" element={<Expenses />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="*" element={<Landing />} />
        </Routes>
      </AnimatePresence>
      <footer className="pb-8 text-center text-xs text-muted">© {new Date().getFullYear()} PocketSmart AI. Demo site: all data is sample data and prices are estimates.</footer>
    </AuthCtx.Provider>
  )
}
