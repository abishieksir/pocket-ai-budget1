// All data here is SAMPLE / DEMO data generated in the browser. No AI model or server is called.
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const rd = (n) => Math.round(n / 10) * 10

const SPLITS = {
  budget: [['Needs', 50, 'Rent, food, bills, transport'], ['Wants', 30, 'Shopping, outings, subscriptions'], ['Savings', 20, 'Emergency fund and goals']],
  home: [['Furniture', 40, 'Main pieces such as sofa, bed or storage'], ['Lighting', 12, 'Ambient and task lights'], ['Decor', 15, 'Art, plants and accessories'], ['Paint & walls', 15, 'Paint, wallpaper, accent wall'], ['Textiles', 10, 'Curtains, rugs, cushions'], ['Contingency', 8, 'Buffer for surprises']],
  party: [['Venue', 30, 'Hall, terrace or home setup'], ['Food', 35, 'Catering or home-cooked menu'], ['Decoration', 12, 'Balloons, lights, backdrop'], ['Entertainment', 13, 'Music, host, games'], ['Miscellaneous', 10, 'Invites, return gifts, buffer']],
  jewelry: [['Jewelry piece', 75, 'Metal and stones'], ['Making charges & GST', 18, 'Varies by jeweller'], ['Insurance & certification', 7, 'Hallmark and purity certificate']],
}

const STYLE_TIPS = {
  Modern: 'Neutral base with one bold accent colour and clean-lined furniture.',
  Minimalist: 'Keep surfaces clear; invest in one statement piece and good storage.',
  'Traditional Indian': 'Carved wood, brass accents and rich textiles such as silk cushions.',
  Scandinavian: 'Light woods, white walls and soft layered textiles.',
  Boho: 'Jute rugs, macramé, plants and mixed patterns.',
  Industrial: 'Exposed finishes, metal frames and warm bulbs.',
}

export async function makePlan(kind, v) {
  await sleep(800)
  const budget = Number(v.budget)
  if (!(budget > 0)) throw new Error('Budget must be greater than 0')
  let split = SPLITS[kind].map(([category, p, note]) => ({ category, p, note }))
  let summary, tips = ['Compare prices on at least two shops or sites.', 'Keep 5-10% aside for surprises.'], suggestions = []

  if (kind === 'budget') {
    summary = `Demo plan for ${v.category || 'your goal'}: a balanced 50/30/20 split of ${budget.toLocaleString('en-IN')} rupees.`
    if (['Wedding', 'Travel', 'Festival'].includes(v.category)) split = [{ category: 'Core costs', p: 60, note: 'Essentials for the event or trip' }, { category: 'Extras', p: 25, note: 'Nice-to-haves' }, { category: 'Buffer', p: 15, note: 'Overruns and emergencies' }]
    suggestions = ['Track every expense for 30 days to see where money really goes.', 'Automate a monthly transfer to savings on payday.']
    tips.push('Cancel subscriptions you have not used in 30 days.')
  } else if (kind === 'home') {
    summary = `Demo ${v.style || 'Modern'} plan for your ${String(v.room_type || 'room').toLowerCase()}. ${STYLE_TIPS[v.style] || STYLE_TIPS.Modern}`
    suggestions = ['Start with lighting and wall colour: biggest change for the least money.', 'Buy the largest piece (sofa or bed) first, then match everything to it.', 'Use one rug and a few cushions to tie colours together.']
    tips.push('Shop festival sales for furniture and lights.')
  } else if (kind === 'party') {
    const g = Math.max(1, Number(v.guests) || 1)
    const perHead = rd(budget / g)
    summary = `Demo ${v.event_type || 'party'} plan for ${g} guests${v.location ? ' in ' + v.location : ''}: roughly ${perHead.toLocaleString('en-IN')} rupees per guest overall.`
    suggestions = [`Food budget works out to about ${rd((budget * 0.35) / g).toLocaleString('en-IN')} rupees per guest.`, 'Book the venue and caterer 3-4 weeks ahead for better rates.', 'A playlist plus a few games can replace a costly live act.']
    if (perHead < 400) tips.push('Budget is tight per guest: consider a home venue or a shorter guest list.')
  } else {
    summary = `Demo guide for a ${String(v.material || 'gold').toLowerCase()} ${String(v.jewelry_type || 'piece').toLowerCase()} within your budget.`
    suggestions = ['Check the hallmark (BIS) and ask for a purity certificate.', 'Ask the jeweller for the making-charge percentage and compare shops.', 'Final price follows the day\'s metal rate, so check it before buying.']
    tips.push('Light, simple designs have lower making charges.')
  }
  if (v.preferences) suggestions.push(`Noted your preference: "${String(v.preferences).slice(0, 120)}".`)
  const breakdown = split.map((s) => ({ category: s.category, amount: rd((budget * s.p) / 100), note: `${s.p}%: ${s.note}` }))
  return { summary, breakdown, tips, suggestions, budget, demo: true }
}

export async function analyzeImage(v) {
  await sleep(900)
  return `Demo suggestions for your ${String(v.room_type || 'room').toLowerCase()} (${v.style || 'Modern'} style). The photo stays in your browser and is not analysed by AI in this demo:\n` +
    '1. Layer warm lighting: one floor lamp plus a table lamp (about ₹4,000-8,000).\n2. Add an accent wall or fresh paint (about ₹6,000-15,000).\n3. Introduce a rug to anchor the seating area (about ₹3,000-9,000).\n4. Use plants and wall art for colour (about ₹2,000-6,000).\n5. Declutter and add closed storage (about ₹8,000-20,000).\nAll numbers are rough demo estimates.'
}

export function chatReply(msg) {
  const t = msg.toLowerCase()
  const m = t.replace(/,/g, '').match(/(\d{3,9})/)
  const amt = m ? Number(m[1]) : null
  const f = (n) => '₹' + n.toLocaleString('en-IN')
  if (amt && /(split|salary|income|budget|save|plan)/.test(t))
    return `With ${f(amt)}, a simple 50/30/20 rule gives: needs ${f(amt * 0.5)}, wants ${f(amt * 0.3)}, savings ${f(amt * 0.2)}. Want me to adjust it for rent or EMIs?`
  if (/(save|saving|cut|reduce)/.test(t)) return 'Quick ways to save: 1) track expenses for a month, 2) cancel unused subscriptions, 3) cook at home 4 days a week, 4) wait 24 hours before non-essential purchases, 5) automate savings on payday.'
  if (/(party|birthday|wedding|event)/.test(t)) return 'For parties, food is usually about 35% of the budget, venue 30%, decor 12%, entertainment 13% and 10% buffer. Try the Party Planner page for a full breakdown.'
  if (/(home|room|interior|sofa|paint)/.test(t)) return 'For a room makeover, lighting and wall colour give the biggest change for the cost. The Home Interior Planner can split your budget by category.'
  if (/(gold|jewel|ring|necklace|silver|diamond)/.test(t)) return 'For jewelry, compare making charges, check BIS hallmark, and confirm the day\'s metal rate. The Jewelry Assistant page shows a typical cost split.'
  if (/(emergency|fund)/.test(t)) return 'An emergency fund of 3-6 months of expenses is a common target. Start small, even 5% of income, and build up.'
  if (/(hi|hello|hey)\b/.test(t)) return 'Hello! Ask me about splitting a salary, saving money, or planning a purchase.'
  return 'I am running in demo mode with preset answers. Try asking: "How should I split ₹50,000 salary?" or "Ways to cut monthly spending".'
}

const P = [
  ['home', 'Solid Wood Sofa (3-seater)', 32000, 'Comfortable teak-finish sofa for living rooms.', '🛋️'],
  ['home', 'Warm LED Floor Lamp', 3500, 'Dimmable ambient light with fabric shade.', '💡'],
  ['home', 'Jute Area Rug 5x7 ft', 4200, 'Natural texture rug for boho or minimal rooms.', '🧶'],
  ['party', 'LED Fairy Lights (10 m)', 450, 'Warm white string lights for stage and walls.', '✨'],
  ['party', 'Birthday Decoration Combo', 1200, 'Balloons, banner and foil curtain set.', '🎈'],
  ['party', 'Portable Bluetooth PA Speaker', 6500, 'Loud speaker with mic input for small events.', '🔊'],
  ['jewelry', 'Gold Stud Earrings (2 g)', 15000, 'Everyday studs. Real price follows the gold rate.', '💎'],
  ['jewelry', 'Sterling Silver Pendant', 2800, '925 silver pendant with chain.', '📿'],
  ['general', 'Budget Planner Notebook', 350, 'Monthly spending tracker with envelopes.', '📒'],
  ['general', 'Smart Wi-Fi Plug', 799, 'Cut standby power costs and track usage.', '🔌'],
]
export const PRODUCTS = P.map(([category, name, price, description, emoji], id) => ({
  id, category, name, price, description, emoji, platform: 'Search online',
  url: 'https://www.google.com/search?q=' + encodeURIComponent(name),
}))
export const PRODUCT_NOTICE = 'Sample products with rough estimated prices. These are not live prices.'

// ---- local storage helpers (data never leaves this browser) ----
const read = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d } catch { return d } }
export const loadExpenses = () => read('ps_expenses', [])
export const saveExpenses = (l) => localStorage.setItem('ps_expenses', JSON.stringify(l))
export const SEED = [
  { id: 1, title: 'Groceries', amount: 3200, category: 'Food', date: new Date().toISOString().slice(0, 10) },
  { id: 2, title: 'Metro card', amount: 800, category: 'Transport', date: new Date().toISOString().slice(0, 10) },
  { id: 3, title: 'Electricity bill', amount: 1500, category: 'Bills', date: new Date().toISOString().slice(0, 10) },
]
