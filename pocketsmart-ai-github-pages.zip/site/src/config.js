// Edit this: the Contact page opens the visitor's email app addressed to this email.
export const CONTACT_EMAIL = 'your-email@example.com'
