import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../auth.js'
import { Page, Field } from '../components/ui.jsx'

export default function Auth() {
  const [f, setF] = useState({ name: '', email: '' })
  const { login } = useAuth()
  const nav = useNavigate()
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })
  const submit = (e) => { e.preventDefault(); login({ name: f.name.trim(), email: f.email.trim() }); nav('/dashboard') }
  return (
    <Page className="max-w-md">
      <form onSubmit={submit} className="glass space-y-4 p-6">
        <h1 className="text-2xl font-bold">Get started</h1>
        <p className="text-sm text-muted">Demo sign-in: your name and email are saved only in this browser. No account is created and no password is needed.</p>
        <Field label="Name"><input className="input" value={f.name} onChange={set('name')} required maxLength={60} /></Field>
        <Field label="Email"><input type="email" className="input" value={f.email} onChange={set('email')} required /></Field>
        <button className="btn w-full">Continue</button>
      </form>
    </Page>
  )
}
