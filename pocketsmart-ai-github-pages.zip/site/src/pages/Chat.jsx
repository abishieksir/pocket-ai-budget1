import { useEffect, useRef, useState } from 'react'
import { Send, Bot, User } from 'lucide-react'
import { chatReply, sleep } from '../demo.js'
import { Page } from '../components/ui.jsx'

const HINTS = ['How should I split ₹50,000 salary?', 'Ways to cut monthly spending', 'Plan a ₹20,000 birthday party']

export default function Chat() {
  const [msgs, setMsgs] = useState([{ role: 'assistant', content: 'Hi! I am PocketSmart AI (demo mode with preset answers). Ask about splitting a salary, saving money or planning a purchase.' }])
  const [text, setText] = useState('')
  const [busy, setBusy] = useState(false)
  const end = useRef()
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs, busy])

  const send = async (m) => {
    m = (m ?? text).trim(); if (!m || busy) return
    setMsgs((x) => [...x, { role: 'user', content: m }]); setText(''); setBusy(true)
    try {
      await sleep(600)
      setMsgs((x) => [...x, { role: 'assistant', content: chatReply(m) }])
    } finally { setBusy(false) }
  }
  return (
    <Page className="max-w-3xl">
      <div className="glass flex h-[70vh] flex-col">
        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          {msgs.map((m, i) => (
            <div key={i} className={`flex gap-2 ${m.role === 'user' ? 'justify-end' : ''}`}>
              {m.role === 'assistant' && <Bot className="mt-1 shrink-0 text-violet-400" size={20} />}
              <div className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-2 text-sm ${m.role === 'user' ? 'bg-violet-600 text-white' : 'bg-white/10'}`}>{m.content}</div>
              {m.role === 'user' && <User className="mt-1 shrink-0 text-muted" size={20} />}
            </div>
          ))}
          {busy && <div className="flex gap-1 pl-7">{[0, 1, 2].map((i) => <span key={i} className="h-2 w-2 animate-bounce rounded-full bg-violet-400" style={{ animationDelay: `${i * .15}s` }} />)}</div>}
          <div ref={end} />
        </div>
        <div className="flex flex-wrap gap-2 px-4">{msgs.length < 2 && HINTS.map((h) => <button key={h} onClick={() => send(h)} className="btn-ghost glass text-xs">{h}</button>)}</div>
        <form onSubmit={(e) => { e.preventDefault(); send() }} className="flex gap-2 p-4">
          <input className="input" placeholder="Type your question…" maxLength={1000} value={text} onChange={(e) => setText(e.target.value)} />
          <button className="btn" disabled={busy} aria-label="Send"><Send size={18} /></button>
        </form>
      </div>
    </Page>
  )
}
