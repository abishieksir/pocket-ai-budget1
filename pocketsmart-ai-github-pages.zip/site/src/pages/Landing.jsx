import { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { motion, animate, useMotionValue, useTransform } from 'framer-motion'
import { Wallet, Home, PartyPopper, Gem, MessageSquare, Receipt, ArrowRight } from 'lucide-react'
import { Page, Card } from '../components/ui.jsx'

function Counter({ to, suffix = '' }) {
  const mv = useMotionValue(0)
  const text = useTransform(mv, (v) => Math.round(v).toLocaleString('en-IN') + suffix)
  useEffect(() => { const c = animate(mv, to, { duration: 1.8 }); return c.stop }, [to])
  return <motion.span>{text}</motion.span>
}

const FEATURES = [
  [Wallet, 'AI Budget Planner', 'Smart breakdown for any goal.', '/budget'],
  [Home, 'Home Interior Planner', 'Styles, costs and room photo analysis.', '/home-planner'],
  [PartyPopper, 'Party Planner', 'Venue, food, decor and fun within budget.', '/party'],
  [Gem, 'Jewelry Assistant', 'Estimate and compare before you buy.', '/jewelry'],
  [MessageSquare, 'AI Chat', 'Ask money questions in plain language.', '/chat'],
  [Receipt, 'Expense Tracker', 'Track spending with live charts.', '/expenses'],
]

export default function Landing() {
  return (
    <Page>
      <section className="py-14 text-center">
        <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-4xl font-extrabold leading-tight sm:text-6xl">
          Spend <span className="gradient-text">smarter</span>.<br />Plan anything with AI.
        </motion.h1>
        <p className="mx-auto mt-5 max-w-xl text-muted">PocketSmart AI turns your budget into a clear plan for your home, parties, jewelry and everyday money.</p>
        <div className="mt-8 flex justify-center gap-3">
          <Link to="/budget" className="btn">Start planning <ArrowRight size={18} /></Link>
          <Link to="/chat" className="btn-ghost glass">Ask the AI</Link>
        </div>
        <div className="mx-auto mt-12 grid max-w-2xl grid-cols-3 gap-3">
          {[[6, '', 'Smart tools'], [100, '%', 'Runs in your browser'], [24, '/7', 'AI assistant']].map(([n, s, l]) => (
            <div key={l} className="glass p-4"><div className="text-2xl font-bold gradient-text"><Counter to={n} suffix={s} /></div><div className="text-xs text-muted">{l}</div></div>
          ))}
        </div>
      </section>
      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {FEATURES.map(([Icon, t, d, to]) => (
          <Link key={to} to={to}><Card className="h-full"><Icon className="mb-3 text-violet-400" /><h3 className="font-semibold">{t}</h3><p className="mt-1 text-sm text-muted">{d}</p></Card></Link>
        ))}
      </section>
    </Page>
  )
}
