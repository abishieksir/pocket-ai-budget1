import { Link } from 'react-router-dom'
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts'
import { Wallet, Home, PartyPopper, Gem, MessageSquare, Receipt } from 'lucide-react'
import { inr } from '../api.js'
import { useAuth } from '../auth.js'
import { Page, Card, COLORS } from '../components/ui.jsx'
import Products from '../components/Products.jsx'
import { useExpenses, byCategory } from './Expenses.jsx'

const ACTIONS = [[Wallet, 'Budget Planner', '/budget'], [Home, 'Home Planner', '/home-planner'], [PartyPopper, 'Party Planner', '/party'],
  [Gem, 'Jewelry', '/jewelry'], [MessageSquare, 'AI Chat', '/chat'], [Receipt, 'Expenses', '/expenses']]

export default function Dashboard() {
  const { user } = useAuth()
  const [list] = useExpenses()
  const total = list.reduce((s, e) => s + e.amount, 0)
  const cats = byCategory(list)
  const top = [...cats].sort((a, b) => b.value - a.value)[0]
  return (
    <Page>
      <h1 className="text-3xl font-extrabold">Hello{user ? `, ${user.name.split(' ')[0]}` : ''} 👋</h1>
      <p className="mb-6 text-muted">Here is your spending snapshot (sample data until you add your own). {!user && <Link to="/auth" className="text-violet-400 underline">Sign in</Link>}</p>
      <div className="grid gap-4 md:grid-cols-3">
        <Card><div className="text-sm text-muted">Total spent</div><div className="text-2xl font-bold">{inr(total)}</div></Card>
        <Card><div className="text-sm text-muted">Expenses logged</div><div className="text-2xl font-bold">{list.length}</div></Card>
        <Card><div className="text-sm text-muted">Top category</div><div className="text-2xl font-bold">{top ? `${top.name}` : '–'}</div></Card>
      </div>
      {!!cats.length && <Card className="mt-4 h-64"><ResponsiveContainer><PieChart><Pie data={cats} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90}>{cats.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip formatter={(v) => inr(v)} /></PieChart></ResponsiveContainer></Card>}
      <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-3">
        {ACTIONS.map(([Icon, t, to]) => <Link key={to} to={to}><Card className="flex items-center gap-3"><Icon className="text-violet-400" /> <span className="font-medium">{t}</span></Card></Link>)}
      </div>
      <Products />
    </Page>
  )
}
