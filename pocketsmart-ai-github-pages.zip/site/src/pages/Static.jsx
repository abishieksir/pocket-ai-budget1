import { useState } from 'react'
import { Shield, Zap, Heart } from 'lucide-react'
import { CONTACT_EMAIL } from '../config.js'
import { Page, Card, Field } from '../components/ui.jsx'

export const About = () => (
  <Page>
    <h1 className="text-3xl font-extrabold">About PocketSmart AI</h1>
    <p className="mt-3 max-w-2xl text-muted">PocketSmart AI helps people plan big and small spending with confidence. This site is a fully in-browser demo: plans, chat replies and products are sample data, so it needs no server and no API keys.</p>
    <div className="mt-8 grid gap-4 md:grid-cols-3">
      {[[Zap, 'Fast plans', 'Budgets for home, parties and jewelry in seconds.'], [Shield, 'Private by design', 'No API keys or backend. Your data stays in your browser.'], [Heart, 'Honest numbers', 'Prices are estimates and sample products are clearly labelled.']].map(([I, t, d]) => (
        <Card key={t}><I className="mb-2 text-violet-400" /><h3 className="font-semibold">{t}</h3><p className="text-sm text-muted">{d}</p></Card>))}
    </div>
  </Page>
)

export function Contact() {
  const [f, setF] = useState({ name: '', email: '', message: '' })
  const [sent, setSent] = useState(false)
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })
  const submit = (e) => {
    e.preventDefault()
    const body = `${f.message}\n\nFrom: ${f.name} (${f.email})`
    window.location.href = `mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent('PocketSmart AI message from ' + f.name)}&body=${encodeURIComponent(body)}`
    setSent(true)
  }
  return (
    <Page className="max-w-xl">
      <form onSubmit={submit} className="glass space-y-4 p-6">
        <h1 className="text-2xl font-bold">Contact us</h1>
        <Field label="Name"><input className="input" required value={f.name} onChange={set('name')} /></Field>
        <Field label="Email"><input type="email" className="input" required value={f.email} onChange={set('email')} /></Field>
        <Field label="Message"><textarea rows={4} className="input" required minLength={5} maxLength={1000} value={f.message} onChange={set('message')} /></Field>
        {sent && <p className="text-sm text-emerald-400">Your email app should open with the message ready to send.</p>}
        <button className="btn w-full">Send via email</button>
      </form>
    </Page>
  )
}
