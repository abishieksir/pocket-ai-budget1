import { useState } from 'react'
import { motion } from 'framer-motion'
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts'
import { Sparkles, ImagePlus } from 'lucide-react'
import { inr } from '../api.js'
import { makePlan, analyzeImage } from '../demo.js'
import { Page, Card, Field, Spinner, COLORS } from '../components/ui.jsx'
import Products from '../components/Products.jsx'

const T = { type: 'text' }
const CONFIGS = {
  budget: {
    title: 'AI Budget Planner', sub: 'Tell us your goal and get a detailed breakdown.', endpoint: '/budget-plan', products: 'general',
    fields: [
      { name: 'budget', label: 'Total budget (₹)', type: 'number', required: true },
      { name: 'category', label: 'Category', select: ['Monthly household', 'Wedding', 'Travel', 'Education', 'Gadgets', 'Festival'] },
      { name: 'preferences', label: 'Preferences', area: true }, { name: 'requirements', label: 'Requirements', area: true }],
  },
  home: {
    title: 'Home Interior Planner', sub: 'Style, estimated costs and shopping ideas. Optionally upload a room photo.', endpoint: '/generate-home', products: 'home', image: true,
    fields: [
      { name: 'room_type', label: 'Room type', select: ['Living room', 'Bedroom', 'Kitchen', 'Bathroom', 'Home office', 'Kids room'], required: true },
      { name: 'budget', label: 'Available budget (₹)', type: 'number', required: true },
      { name: 'style', label: 'Design style', select: ['Modern', 'Minimalist', 'Traditional Indian', 'Scandinavian', 'Boho', 'Industrial'] },
      { name: 'preferences', label: 'Preferences', area: true }],
  },
  party: {
    title: 'Party Event Planner', sub: 'Venue, food, decoration and entertainment within your budget.', endpoint: '/generate-party', products: 'party',
    fields: [
      { name: 'event_type', label: 'Event type', select: ['Birthday', 'Wedding reception', 'Anniversary', 'Baby shower', 'Corporate event', 'Housewarming'], required: true },
      { name: 'guests', label: 'Number of guests', type: 'number', required: true },
      { name: 'budget', label: 'Total budget (₹)', type: 'number', required: true },
      { name: 'location', label: 'Location (city)', ...T }, { name: 'preferences', label: 'Preferences', area: true }],
  },
  jewelry: {
    title: 'Jewelry Shopping Assistant', sub: 'Get recommendations with estimated prices.', endpoint: '/generate-jewelry', products: 'jewelry',
    fields: [
      { name: 'budget', label: 'Budget (₹)', type: 'number', required: true },
      { name: 'jewelry_type', label: 'Jewelry type', select: ['Necklace', 'Earrings', 'Ring', 'Bangles', 'Chain', 'Pendant'], required: true },
      { name: 'material', label: 'Material', select: ['Gold 22K', 'Gold 18K', 'Silver', 'Diamond', 'Platinum', 'Artificial'] },
      { name: 'preferences', label: 'Preferences', area: true }],
  },
}

export default function Planner({ kind }) {
  const cfg = CONFIGS[kind]
  const [vals, setVals] = useState({})
  const [file, setFile] = useState(null)
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const [res, setRes] = useState(null)
  const [analysis, setAnalysis] = useState(null)
  const set = (k) => (e) => setVals({ ...vals, [k]: e.target.value })

  const submit = async (e) => {
    e.preventDefault(); setErr(''); setRes(null); setAnalysis(null); setBusy(true)
    const body = { ...vals }
    cfg.fields.forEach((f) => { if (f.select && !body[f.name]) body[f.name] = f.select[0] })
    try {
      const [plan, img] = await Promise.all([makePlan(kind, body), file ? analyzeImage(body) : null])
      setRes(plan); if (img) setAnalysis(img)
    } catch (x) { setErr(x.message) } finally { setBusy(false) }
  }

  const total = res?.breakdown?.reduce((s, b) => s + Number(b.amount || 0), 0) || 0
  return (
    <Page>
      <h1 className="text-3xl font-extrabold">{cfg.title}</h1>
      <p className="mb-6 text-muted">{cfg.sub}</p>
      <div className="grid gap-6 lg:grid-cols-[380px_1fr]">
        <form onSubmit={submit} className="glass space-y-4 p-5 self-start">
          {cfg.fields.map((f) => (
            <Field key={f.name} label={f.label + (f.required ? ' *' : '')}>
              {f.select ? <select className="input" value={vals[f.name] || f.select[0]} onChange={set(f.name)}>{f.select.map((o) => <option key={o}>{o}</option>)}</select>
                : f.area ? <textarea rows={2} maxLength={300} className="input" value={vals[f.name] || ''} onChange={set(f.name)} />
                : <input className="input" type={f.type} min={f.type === 'number' ? 1 : undefined} required={f.required} value={vals[f.name] || ''} onChange={set(f.name)} />}
            </Field>
          ))}
          {cfg.image && (
            <Field label="Room photo (JPG/PNG/WebP, max 5 MB)">
              <label className="input flex cursor-pointer items-center gap-2 text-muted"><ImagePlus size={18} /> {file ? file.name : 'Choose image'}
                <input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={(e) => {
                  const f = e.target.files[0]
                  if (f && !['image/jpeg', 'image/png', 'image/webp'].includes(f.type)) { setErr('Only JPG, PNG or WebP images'); return }
                  if (f && f.size > 5 * 1024 * 1024) { setErr('Image must be under 5 MB'); return }
                  setErr(''); setFile(f || null)
                }} /></label>
            </Field>
          )}
          <button className="btn w-full" disabled={busy}><Sparkles size={18} /> {busy ? 'Generating…' : 'Generate plan'}</button>
          {err && <p className="text-sm text-rose-400">{err}</p>}
        </form>

        <div>
          {busy && <Card><Spinner label="Generating your plan…" /></Card>}
          {!busy && !res && <Card className="text-muted">Fill in the form and your plan will appear here.</Card>}
          {res && (
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
              <div className="rounded-xl bg-amber-400/15 p-3 text-sm text-amber-300">Demo mode: this plan is generated in your browser from sample rules. No AI model is called.</div>
              <Card><p>{res.summary}</p></Card>
              <Card>
                <h3 className="mb-3 font-semibold">Budget breakdown · {inr(res.budget)}</h3>
                <div className="grid items-center gap-4 sm:grid-cols-2">
                  <div className="h-56"><ResponsiveContainer><PieChart><Pie data={res.breakdown} dataKey="amount" nameKey="category" innerRadius={50} outerRadius={85} paddingAngle={3}>
                    {res.breakdown.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip formatter={(v) => inr(v)} /></PieChart></ResponsiveContainer></div>
                  <ul className="space-y-2 text-sm">{res.breakdown.map((b, i) => (
                    <li key={i} className="flex justify-between gap-2"><span><i className="mr-2 inline-block h-2.5 w-2.5 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />{b.category}<span className="block pl-5 text-xs text-muted">{b.note}</span></span><b>{inr(b.amount)}</b></li>))}
                    <li className="flex justify-between border-t border-white/10 pt-2 text-muted"><span>Total planned</span><span>{inr(total)}</span></li></ul>
                </div>
              </Card>
              {!!res.suggestions?.length && <Card><h3 className="mb-2 font-semibold">Recommendations</h3><ul className="list-disc space-y-1 pl-5 text-sm">{res.suggestions.map((s, i) => <li key={i}>{s}</li>)}</ul></Card>}
              {!!res.tips?.length && <Card><h3 className="mb-2 font-semibold">Money-saving tips</h3><ul className="list-disc space-y-1 pl-5 text-sm">{res.tips.map((s, i) => <li key={i}>{s}</li>)}</ul></Card>}
              {analysis && <Card><h3 className="mb-2 font-semibold">Room photo analysis (demo)</h3>{file && <img alt="Your room" src={URL.createObjectURL(file)} className="mb-3 max-h-48 rounded-xl" />}<p className="whitespace-pre-wrap text-sm">{analysis}</p></Card>}
              <p className="text-xs text-muted">All amounts are demo estimates, not live prices.</p>
            </motion.div>
          )}
        </div>
      </div>
      <Products category={cfg.products} />
    </Page>
  )
}
