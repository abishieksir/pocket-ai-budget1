import { useMemo, useState } from 'react'
import { Pencil, Trash2, Plus } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import { inr } from '../api.js'
import { loadExpenses, saveExpenses, SEED } from '../demo.js'
import { Page, Card, Field, COLORS } from '../components/ui.jsx'

export const CATS = ['Food', 'Rent', 'Transport', 'Shopping', 'Bills', 'Health', 'Entertainment', 'Other']
const blank = { title: '', amount: '', category: 'Food', date: new Date().toISOString().slice(0, 10) }

export function useExpenses() {
  const [list, setList] = useState(() => {
    const l = loadExpenses()
    if (!l.length && !localStorage.getItem('ps_seeded')) { localStorage.setItem('ps_seeded', '1'); saveExpenses(SEED); return SEED }
    return l
  })
  const update = (l) => { saveExpenses(l); setList(l) }
  return [list, update]
}
export const byCategory = (list) => Object.entries(list.reduce((a, e) => ({ ...a, [e.category]: (a[e.category] || 0) + e.amount }), {})).map(([name, value]) => ({ name, value }))

export default function Expenses() {
  const [list, update] = useExpenses()
  const [f, setF] = useState(blank)
  const [editId, setEditId] = useState(null)
  const [err, setErr] = useState('')
  const [budget, setBudget] = useState(localStorage.getItem('ps_budget') || '')
  const total = useMemo(() => list.reduce((s, e) => s + e.amount, 0), [list])
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })

  const save = (e) => {
    e.preventDefault(); setErr('')
    const amount = Number(f.amount), title = f.title.trim()
    if (!title || !(amount > 0)) { setErr('Enter a title and an amount above 0'); return }
    const item = { title, amount, category: f.category, date: f.date || blank.date }
    update(editId ? list.map((x) => (x.id === editId ? { ...x, ...item } : x)) : [{ id: Date.now(), ...item }, ...list])
    setF(blank); setEditId(null)
  }
  const remove = (id) => { if (confirm('Delete this expense?')) update(list.filter((x) => x.id !== id)) }
  const left = budget ? Number(budget) - total : null

  return (
    <Page>
      <h1 className="text-3xl font-extrabold">Expense Tracker</h1>
      <p className="mb-6 text-sm text-muted">Saved only in this browser. Starts with a few sample entries you can edit or delete.</p>
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <Card><div className="text-sm text-muted">Total spent</div><div className="text-2xl font-bold">{inr(total)}</div></Card>
        <Card><div className="text-sm text-muted">Monthly budget (₹)</div>
          <input type="number" min="0" className="input mt-1" value={budget} onChange={(e) => { setBudget(e.target.value); localStorage.setItem('ps_budget', e.target.value) }} /></Card>
        <Card><div className="text-sm text-muted">Remaining</div><div className={`text-2xl font-bold ${left < 0 ? 'text-rose-400' : 'text-emerald-400'}`}>{left === null ? '–' : inr(left)}</div></Card>
      </div>
      <div className="grid gap-6 lg:grid-cols-[340px_1fr]">
        <form onSubmit={save} className="glass space-y-3 self-start p-5">
          <h2 className="font-semibold">{editId ? 'Edit expense' : 'Add expense'}</h2>
          <Field label="Title"><input className="input" required maxLength={80} value={f.title} onChange={set('title')} /></Field>
          <Field label="Amount (₹)"><input className="input" type="number" min="1" required value={f.amount} onChange={set('amount')} /></Field>
          <Field label="Category"><select className="input" value={f.category} onChange={set('category')}>{CATS.map((c) => <option key={c}>{c}</option>)}</select></Field>
          <Field label="Date"><input className="input" type="date" value={f.date} onChange={set('date')} /></Field>
          {err && <p className="text-sm text-rose-400">{err}</p>}
          <div className="flex gap-2"><button className="btn flex-1"><Plus size={16} /> {editId ? 'Update' : 'Add'}</button>
            {editId && <button type="button" className="btn-ghost glass" onClick={() => { setEditId(null); setF(blank) }}>Cancel</button>}</div>
        </form>
        <div className="space-y-4">
          <Card className="h-64">
            {list.length ? <ResponsiveContainer><BarChart data={byCategory(list)}><XAxis dataKey="name" stroke="#8b93b8" fontSize={12} /><YAxis stroke="#8b93b8" fontSize={12} /><Tooltip formatter={(v) => inr(v)} />
              <Bar dataKey="value" radius={[8, 8, 0, 0]}>{byCategory(list).map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Bar></BarChart></ResponsiveContainer>
              : <p className="text-muted">Add an expense to see your category chart.</p>}
          </Card>
          <div className="glass divide-y divide-white/10">
            {list.map((e) => (
              <div key={e.id} className="flex items-center justify-between gap-2 p-3 text-sm">
                <div><div className="font-medium">{e.title}</div><div className="text-xs text-muted">{e.category} · {e.date}</div></div>
                <div className="flex items-center gap-2"><b>{inr(e.amount)}</b>
                  <button className="btn-ghost" aria-label="Edit" onClick={() => { setEditId(e.id); setF({ title: e.title, amount: e.amount, category: e.category, date: e.date }) }}><Pencil size={15} /></button>
                  <button className="btn-ghost text-rose-400" aria-label="Delete" onClick={() => remove(e.id)}><Trash2 size={15} /></button></div>
              </div>))}
            {!list.length && <p className="p-4 text-muted">No expenses yet.</p>}
          </div>
        </div>
      </div>
    </Page>
  )
}
