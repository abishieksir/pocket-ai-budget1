import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// VITE_BASE is set by the GitHub Actions workflow (e.g. /my-repo/).
// Locally it falls back to './' so the build also works from any folder.
export default defineConfig({ base: process.env.VITE_BASE || './', plugins: [react()] })
