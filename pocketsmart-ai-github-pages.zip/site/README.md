# PocketSmart AI

A premium AI-SaaS-style budget and recommendation website built with **React + Vite + Tailwind CSS + Framer Motion + Recharts**.
It is a **static demo site**: no backend, no API keys, and GitHub Pages is the only hosting you need.

## What works (all with sample/demo data)
- Budget Planner, Home Interior Planner (with room photo preview), Party Planner, Jewelry Assistant
- AI Chat UI with preset demo answers
- Expense tracker (add, edit, delete, charts), saved in your browser only
- Dashboard, product recommendation cards, light/dark theme, animations, glassmorphism, mobile layout

Plans, chat replies and products are generated in the browser from sample rules. Prices are rough estimates, **not live prices**.
No AI model is called, and uploaded photos never leave your device.

## Deploy to GitHub Pages (5 steps)
1. Create a new **public** repository on GitHub.
2. Upload **the contents of this folder** (so `package.json` and `.github` are at the repo root) to the `main` branch.
   With git:
   ```bash
   git init
   git add .
   git commit -m "PocketSmart AI"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```
3. In the repo go to **Settings → Pages**, and under **Source** choose **GitHub Actions**.
4. Open the **Actions** tab. The *Deploy to GitHub Pages* workflow runs on every push to `main` (first run starts after step 2/3; use **Run workflow** if needed).
5. When it turns green, your site is live at `https://YOUR_USERNAME.github.io/YOUR_REPO/`.

The workflow sets the Vite base path to `/YOUR_REPO/` automatically (and `/` for a `username.github.io` repo).
The site uses hash URLs (`#/budget`), so page refreshes never 404 on GitHub Pages.

## Run locally
```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build in dist/
```
Requires Node 18+.

## Customise
- Contact page: edit the email in `src/config.js`. The form opens the visitor's email app.
- Demo logic and sample products: `src/demo.js`.

## About real AI (Gemini)
Never put a Gemini API key in a GitHub Pages site: everything in the browser is public. Real AI answers need a server
(or serverless function) that holds the key. This project intentionally stays key-free.
